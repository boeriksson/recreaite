import React, { createContext, useContext, useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';

const GenerationStatusContext = createContext();

export const useGenerationStatus = () => {
  const context = useContext(GenerationStatusContext);
  if (!context) {
    throw new Error('useGenerationStatus must be used within GenerationStatusProvider');
  }
  return context;
};

export const GenerationStatusProvider = ({ children }) => {
  const [processingImages, setProcessingImages] = useState([]);

  useEffect(() => {
    // Subscribe to GeneratedImage changes
    const unsubscribe = base44.entities.GeneratedImage.subscribe((event) => {
      if (event.type === 'create' || event.type === 'update') {
        const image = event.data;
        if (image.status === 'processing' || image.status === 'pending') {
          // Add or update processing image
          setProcessingImages(prev => {
            const existing = prev.find(img => img.id === image.id);
            if (existing) {
              return prev.map(img => img.id === image.id ? image : img);
            }
            return [...prev, image];
          });
        } else if (image.status === 'completed' || image.status === 'failed') {
          // Remove from processing list
          setProcessingImages(prev => prev.filter(img => img.id !== image.id));
        }
      } else if (event.type === 'delete') {
        setProcessingImages(prev => prev.filter(img => img.id !== event.id));
      }
    });

    // Load initial processing images
    const loadProcessingImages = async () => {
      try {
        const allImages = await base44.entities.GeneratedImage.list();
        const processing = allImages.filter(img => 
          img.status === 'processing' || img.status === 'pending'
        );
        setProcessingImages(processing);
      } catch (error) {
        console.error('Failed to load processing images:', error);
      }
    };

    loadProcessingImages();

    return unsubscribe;
  }, []);

  return (
    <GenerationStatusContext.Provider value={{ processingImages }}>
      {children}
    </GenerationStatusContext.Provider>
  );
};